Занятие 5 (This, function constructor, Call/Apply/Bind):

Изучить ссылки в файле lesson5.ts

Задания:
1) Решить все задачи.
2) Много времени функциям конструкторам не уделять
3) Решить все задачи на this и call,apply,bind на learn.javascript.ru 