Информация по каждому занятию находится в папке соответствующего занятия в файле README.md
по следующему пути: src/lessons 

Темы занятий:
1) Редакс круговорот, useDispatch, useSelector
2) Замыкание и Рекурсия
3) Работа с простейшими API с помощью axios, Promise
4) Promise
5) This, function constructor, Call/Apply/Bind
6) Class
7) __Proto__ / Prototype
8) Задачи на повторение пройденного материала